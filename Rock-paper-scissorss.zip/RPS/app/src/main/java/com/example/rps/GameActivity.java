package com.example.rps;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.Color;
import java.util.Random;

public class GameActivity extends AppCompatActivity {

    private int playerScore = 0;
    private int computerScore = 0;
    private TextView scoreTextView;
    private TextView resultTextView;
    private ImageView computerChoiceImage;
    private Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // 1. Initialize UI elements
        scoreTextView = findViewById(R.id.scoreTextView);
        resultTextView = findViewById(R.id.resultTextView);
        computerChoiceImage = findViewById(R.id.computerChoiceImage);
        ImageButton btnRock = findViewById(R.id.btnRock);
        ImageButton btnPaper = findViewById(R.id.btnPaper);
        ImageButton btnScissors = findViewById(R.id.btnScissors);

        // 2. Initialize the Random object
        random = new Random();

        // 3. Set Click Listeners
        btnRock.setOnClickListener(v -> handleGame("Rock"));
        btnPaper.setOnClickListener(v -> handleGame("Paper"));
        btnScissors.setOnClickListener(v -> handleGame("Scissors"));

        updateScoreText();
    }

    private void handleGame(String playerMove) {
        String computerMove = generateComputerMove();
        String result = determineWinner(playerMove, computerMove);

        // Update score
        if (result.equals("Win")) {
            playerScore++;
        } else if (result.equals("Lose")) {
            computerScore++;
        }

        // Update UI
        updateComputerImage(computerMove);
        updateScoreText();
        updateResultText(result, playerMove, computerMove);
    }

    private String generateComputerMove() {
        int choice = random.nextInt(3);
        switch (choice) {
            case 0: return "Rock";
            case 1: return "Paper";
            case 2: return "Scissors";
            default: return "";
        }
    }

    private String determineWinner(String player, String computer) {
        if (player.equals(computer)) {
            return "Tie";
        }
        // Win conditions
        if ((player.equals("Rock") && computer.equals("Scissors")) ||
                (player.equals("Paper") && computer.equals("Rock")) ||
                (player.equals("Scissors") && computer.equals("Paper"))) {
            return "Win";
        }
        return "Lose";
    }

    private void updateScoreText() {
        String scoreText = "Player " + playerScore + " - " + computerScore + " Computer";
        scoreTextView.setText(scoreText);
    }

    private void updateResultText(String result, String playerMove, String computerMove) {
        String feedback = "You chose " + playerMove + ". Computer chose " + computerMove + ". \n";

        if (result.equals("Win")) {
            resultTextView.setText(feedback + "You WIN the round!");
            resultTextView.setTextColor(Color.parseColor("#4CAF50")); // Green
        } else if (result.equals("Lose")) {
            resultTextView.setText(feedback + "You LOSE the round!");
            resultTextView.setTextColor(Color.parseColor("#F44336")); // Red
        } else { // Tie
            resultTextView.setText(feedback + "It's a TIE!");
            resultTextView.setTextColor(Color.parseColor("#2196F3")); // Blue
        }
    }

    private void updateComputerImage(String computerMove) {
        int drawableId;

        // CHECK YOUR DRAWABLE NAMES! Ensure these match the files in res/drawable
        if (computerMove.equals("Rock")) {
            drawableId = R.drawable.rock;
        } else if (computerMove.equals("Paper")) {
            drawableId = R.drawable.paper;
        } else { // Scissors
            drawableId = R.drawable.scissors;
        }
        computerChoiceImage.setImageResource(drawableId);
    }
}